CREATE TRIGGER businessReceiptRevenueTrigger
  AFTER INSERT
  ON business_receipt_revenue
  FOR EACH ROW
  begin
	/*款项类型*/
	declare var_received_type int(11);
	/*订单ID*/
    declare var_order_id int(11);
	/*收款币种*/
	declare var_currency int(11);
	/*款项登记表ID*/
	declare var_remittance_id int(11);
    /*认领金额*/
    declare var_income_finance_money decimal(20,4);
    set var_received_type = new.type;
	set var_order_id = new.order_id;
	set var_currency = new.currency;
	set var_remittance_id = new.register_id;
	set var_income_finance_money = new.usd_loans_money;
	/*调用收到人民币保证金的处理逻辑*/
	if var_received_type=-2022104603 and var_currency=-2022102001 then
		call processEnsureMoneyTask(var_received_type,var_order_id,var_currency,var_remittance_id,var_income_finance_money);
	end if;
 	/*调用收到美金合同金额的处理逻辑*/
    if var_received_type=-2022104623 and var_currency=-2022102002 then
		call processContractMoneyTask(var_received_type,var_order_id,var_currency,var_remittance_id,var_income_finance_money);
	end if;
end;

