CREATE PROCEDURE processEnsureMoneyTask(IN var_received_type INT, IN var_order_id INT, IN var_currency INT,
                                        IN var_remittance_id INT, IN var_ensure_money DECIMAL(20, 4))
  begin
	/*打款日期*/
	declare var_pay_date date;
    /*打款日期距离今天有几天*/
    declare var_days int;
	/*循环变量*/
    declare var_i int;
    declare var_serial_no int;
    declare var_interest_rate decimal(20,4);
    declare var_temp_cal_date date;
	set var_i=0;
    
	SELECT interest into var_interest_rate FROM business_bank_interest where start_date <= curdate() and end_date >= curdate();
    /*CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC*/
	/*实收表登记的是人名币保证金*/
	if ((var_received_type = -2022104603) and (var_currency= -2022102001) ) then
		/*查询保证金的打款日期*/
        select remit_date into var_pay_date from bus_remittance where id = var_remittance_id;
        set var_temp_cal_date = var_pay_date;
        select datediff(curdate(),var_pay_date) into var_days;
		select current_no into var_serial_no from sys_sequence where table_name = 'business_ensure_money_interest_serial_no';
        /*如果var_days >0 表示认领保证金在保证金打款之后的几天，所以需要把前面几天的利息也算上去*/
        if var_days > 0 then 
			while var_i <= var_days do
				insert into business_ensure_money_interest (serial_no,order_id,current_interest_rate,ensure_money,cal_date,interest,create_date,finish_flag) 
					values (var_serial_no,var_order_id,var_interest_rate,var_ensure_money,var_temp_cal_date,var_interest_rate*ensure_money/360,curdate(),-2022101002);				
				set var_temp_cal_date = date_add(var_temp_cal_date, interval 1 day);
				set var_i=var_i+1;
			end while;
        else
			insert into business_ensure_money_interest (serial_no,order_id,current_interest_rate,ensure_money,cal_date,interest,create_date,finish_flag ) 
				values (var_serial_no,var_order_id,var_interest_rate,var_ensure_money,curdate(),var_interest_rate*ensure_money/360,curdate(),-2022101002);
        end if;
		update sys_sequence set current_no = current_no+1 where table_name = 'business_ensure_money_interest_serial_no';
	end if;
	/*CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC*/
end;

