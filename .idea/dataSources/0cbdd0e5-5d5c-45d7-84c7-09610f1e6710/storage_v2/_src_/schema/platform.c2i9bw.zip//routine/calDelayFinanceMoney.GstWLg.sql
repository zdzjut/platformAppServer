CREATE PROCEDURE calDelayFinanceMoney()
  begin
	DECLARE done INT DEFAULT 0;
    /*融资款是否已发放*/
    declare var_is_finance_money_give int;
	/*订单账期*/
    declare var_bill_period int;
    /*订单放款日期*/
    declare var_fk_date date;
    /*订单融资款*/
    declare var_finance_money decimal(20,4);
    /*订单融资服务费率*/
    declare var_finance_rate decimal(20,4);
    /*订单已收尾款*/
    declare var_income_contract_money decimal(20,4);
    /*超过账期几天*/
    declare var_delay_day int;
    /*订单ID*/
	declare var_order_id int(11);
    /*逾期待冲账表中的未冲账订单ID*/
    declare var_not_reverse_order_id int(11);
    /*声明游标,查询融资款逾期待冲账表*/
    declare var_not_reverse_orders_cursor cursor for select distinct order_id from business_finance_reverse_detail where has_reverse = -2022101002;
	/*声明游标，查询做货款融资，且在客户回款状态中的订单*/
	declare var_orders_cursor  cursor for select id,bill_period,finance_rate from business_orders where finance_type in (-2022104501,-2022104502,-2022104504,-2022104505) and order_status = -2022106919
		and id not in (select distinct order_id from business_finance_reverse_detail where has_reverse = -2022101002);    
	/*游标结束标识*/ 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	/*打开游标*/
    open var_not_reverse_orders_cursor;
		myLoop:loop
			fetch var_not_reverse_orders_cursor into var_not_reverse_order_id; 
			if done then
				leave myLoop;
			end if;
            /*计算日前一天的逾期记录*/
            select bill_period,delay_day,finance_rate,loan_date into var_bill_period,var_delay_day,var_finance_rate,var_fk_date from business_finance_reverse_detail where id = (select max(id) from business_finance_reverse_detail where reverse_type=-2022104613  and order_id = var_not_reverse_order_id);
			/*逾期利息以最后一次的应还本金为基础计算*/
			select finance_money into var_finance_money from business_finance_reverse_detail where id = (select max(id) from business_finance_reverse_detail where reverse_type=-2022104604 and has_reverse = -2022101002 and order_id = var_not_reverse_order_id);
			if datediff(current_date(),var_fk_date) > var_bill_period + 7 then
				insert into business_finance_reverse_detail (order_id,finance_money,finance_rate,log_date,loan_date,bill_period,delay_day,reverse_money,reverse_type,has_reverse,has_reverse_money,creator,create_date,updator,update_date) values
				(var_not_reverse_order_id,var_finance_money,var_finance_rate,current_date(),var_fk_date,var_bill_period,var_delay_day+1,var_finance_money*var_finance_rate*4,-2022104613,-2022101002,0,null,current_date(),null,current_date());
			else
				insert into business_finance_reverse_detail (order_id,finance_money,finance_rate,log_date,loan_date,bill_period,delay_day,reverse_money,reverse_type,has_reverse,has_reverse_money,creator,create_date,updator,update_date) values
				(var_not_reverse_order_id,var_finance_money,var_finance_rate,current_date(),var_fk_date,var_bill_period,var_delay_day+1,var_finance_money*var_finance_rate,-2022104613,-2022101002,0,null,current_date(),null,current_date());			
			end if;
		end loop myLoop;
	close var_not_reverse_orders_cursor; 
	set done = 0;   
    /*打开游标*/
    open var_orders_cursor;
		myLoop:loop
			fetch var_orders_cursor into var_order_id,var_bill_period,var_finance_rate;            
            if done = 1 then
				leave myLoop;
			end if;
            select count(1) into var_is_finance_money_give from business_payment_revenue where order_id = var_order_id and payment_type=-2022104604;
            /*融资款已经发放*/
            if var_is_finance_money_give > 0 then 
				/*查询放款日期*/
				select min(fk_date) into var_fk_date from business_payment_revenue where order_id = var_order_id and payment_type=-2022104604;				
                /*如果计算日距离订单的放款日超过90天，且融资款未收齐，则需要开始计算逾期费用*/
				if datediff(current_date(),var_fk_date) > var_bill_period then
					/*查询订单放款金额*/
					select usd_melt_money into var_finance_money from business_payment where order_id =var_order_id and supplier_id = -1;
					/*查询已收订单美金合同金额,现在表里还有一条结汇后的人民币金额*/
					select ifnull(sum(usd_loans_money),0) into var_income_contract_money from business_receipt_revenue where order_id = var_order_id and type=-2022104623 and currency = -2022102002;
					/*已收的合同金额 < 发放的融资款*/
					if var_income_contract_money < var_finance_money then
						insert into business_finance_reverse_detail (order_id,finance_money,finance_rate,log_date,loan_date,bill_period,delay_day,reverse_money,reverse_type,has_reverse,has_reverse_money,creator,create_date,updator,update_date) 
							values (var_order_id,var_finance_money - var_income_contract_money,var_finance_rate,current_date(),var_fk_date,var_bill_period,1,var_finance_money - var_income_contract_money,-2022104604,-2022101002,0,null,current_date(),null,current_date());
						insert into business_finance_reverse_detail (order_id,finance_money,finance_rate,log_date,loan_date,bill_period,delay_day,reverse_money,reverse_type,has_reverse,has_reverse_money,creator,create_date,updator,update_date) 
							values (var_order_id,var_finance_money - var_income_contract_money,var_finance_rate,current_date(),var_fk_date,var_bill_period,1,(var_finance_money - var_income_contract_money)*var_finance_rate,-2022104613,-2022101002,0,null,current_date(),null,current_date());                    
					end if;
				end if;
			end if;
		end loop myLoop;
	close var_orders_cursor;
END;

