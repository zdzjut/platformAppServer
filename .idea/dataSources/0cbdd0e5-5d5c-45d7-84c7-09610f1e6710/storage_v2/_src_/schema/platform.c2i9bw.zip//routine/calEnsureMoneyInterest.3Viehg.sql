CREATE PROCEDURE calEnsureMoneyInterest()
  begin
	DECLARE done INT DEFAULT 0;
    /*融资款是否已发放*/
    declare var_is_finance_money_give int;
    /*订单ID*/
	declare var_order_id int(11);
    declare var_serial_no int;
    declare var_ensure_money decimal(20,4);
    declare var_exist_flag int;
    declare var_interest_rate decimal(20,4);
    /*声明游标,每天凌晨00:10分开始计算当天的保证金利息，当天的利息以前一天的数据为基础进行计算*/
    declare var_cursor cursor for select distinct serial_no from business_ensure_money_interest where cal_date = date_add(curdate(), interval -1 day) and finish_flag = -2022101002;
	/*游标结束标识*/ 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	SELECT interest into var_interest_rate FROM business_bank_interest where start_date <= curdate() and end_date >= curdate();
    /*打开游标*/
    open var_cursor;
		myLoop:loop
			fetch var_cursor into var_serial_no;     
			if done then
				leave myLoop;
			end if;
			select order_id,ensure_money into var_order_id,var_ensure_money from business_ensure_money_interest where id = (select max(id) from business_ensure_money_interest where serial_no = var_serial_no);
            /*查询当天利息是否已经计算过，因为新添加的保证金会把当天的保证金利息计算掉，所以不用再次计算*/
            select count(1) into var_exist_flag from business_ensure_money_interest where serial_no = var_serial_no and cal_date = date_add(curdate(), interval -1 day);
            if var_exist_flag = 0 then
				if var_ensure_money > 0 then 
					insert into business_ensure_money_interest (serial_no,order_id,current_interest_rate,ensure_money,cal_date,interest,create_date,finish_flag) 
						values (var_serial_no,var_order_id,var_interest_rate,var_ensure_money,date_add(curdate(), interval -1 day),var_interest_rate*ensure_money/360,curdate(),-2022101002);
				end if;
			end if;
		end loop myLoop;
	close var_cursor;
END;

