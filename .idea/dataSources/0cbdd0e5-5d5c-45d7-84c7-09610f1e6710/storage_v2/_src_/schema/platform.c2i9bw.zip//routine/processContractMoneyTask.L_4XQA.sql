CREATE PROCEDURE processContractMoneyTask(IN var_received_type INT, IN var_order_id INT, IN var_currency INT,
                                          IN var_remittance_id INT, IN var_income_finance_money DECIMAL(20, 4))
  begin
	DECLARE done INT DEFAULT 0;
	/*临时变量,遍历游标var_cur2*/
	declare var_finance_fee2_id int(11);
    /*临时变量,遍历游标var_cur2*/
    declare var_can_use_service_fee decimal(20,4); 
    /*临时变量,遍历游标var_cur2*/
    declare var_temp_reverse_actual_money decimal(20,4);
    /*订单融资款是否已还清*/
    declare var_finish int;
    /*逾期账目是否已经全部回销*/
    declare var_has_reverse int;
	/*订单总的融资金额*/
	declare var_finance_money decimal(20,4);
    /*总的已收融资款*/
    declare var_sum_finance_money decimal(20,4);
	/*汇款日期*/
	declare var_remittance_date date;
	/*融资服务费率*/
	declare var_finance_rate decimal(20,4);
	/*账期*/
	declare var_bill_period int(11);
	/*融资类型*/
	declare var_finance_type int(11);
	/*回款资金实际使用天数*/
	declare var_use_days int(11);
	/*汇款资金实际利息（即融资服务费用）*/
	declare var_finance_service_fee decimal(20,4) default 0;
	/*融资款放款日期*/
	declare var_loan_date date;
	/*已经收到的合同金额*/
	declare var_has_pay_finance_money decimal(20,4);
	/*计算本次融资服务费基础金额*/
	declare var_base_cal_money decimal(20,4);
    /*融资款提前回款部分，需退回部分融资服务费*/
    declare var_back_finance_service_fee decimal(20,4);
    /*订单共总可退回的融资服务费*/
    declare var_sum_back_finance_service_fee decimal(20,4);    
	/*预收融资服务费*/
	declare var_usd_service_payable decimal(20,4);
    /*待冲记录表ID*/
    declare var_reverse_id int(11);
    /*待冲记录表逾期本金*/
    declare var_reverse_finance_money decimal(20,4);
    /*待冲记录表待冲金额*/
    declare var_reverse_money decimal(20,4);
    /*待冲记录表待冲金额类型，本金或者利息*/
    declare var_reverse_type int(11);
    /*待冲记录表第几天的逾期*/
    declare var_reverse_delay_day int;
    /*逾期还款的时候，实际的还融资款金额，等于本金+逾期服务费*/
    declare var_reverse_actual_money decimal(20,4) default 0;
    /*查询待冲的逾期财务账，如果是提前还款，这里是查不到记录的*/
    declare var_finance_reverse_detail_cursor cursor  for select id,order_id,finance_money,reverse_money,reverse_type,delay_day 
		from business_finance_reverse_detail where order_id = new.order_id and has_reverse = -2022101002 order by reverse_type asc, id desc;
	/*需要回写应退融资服务费使用情况的记录*/
    declare var_cur2 cursor for select id,back_finance_service_fee-reverse_finance_service_fee 
		from business_finance_service_fee2 where finish_flag = -2022101002 and order_id= new.order_id and finance_service_fee is not null and reverse_finance_service_fee < back_finance_service_fee;
	/*游标结束标识*/ 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	/*查询订单的融资类型/账期/融资服务费率*/
	select bill_period,finance_rate,finance_type into var_bill_period,var_finance_rate,var_finance_type from business_orders where id = var_order_id;  
	/*
	触发计算融资服务费的条件
	1.收到的款项类型为合同金额
	2.融资类型为货款融资(信用证)/货款融资(非信用证)/货税均融(信用证)/货税均融(非信用证)
	3.本次回款之前已经收到的合同金额 < 订单的融资款
	*/
	/*CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC*/
	/*融资类型为货款融资(信用证)/货款融资(非信用证)/货税均融(信用证)/货税均融(非信用证),才需要记录到融资款回款记录表和执行逾期冲账操作*/
	if ((var_finance_type= -2022104501) or (var_finance_type= -2022104502) or (var_finance_type= -2022104504) or (var_finance_type= -2022104505)) then
		/*查询订单是否已经还清融资款,如果查到记录表示已经还清，如果没查到记录，则表示还没还清*/
        select count(1) into var_finish from business_finance_service_fee2 where finish_flag = -2022101001 and order_id=var_order_id;
        /*EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE*/
        if var_finish = 0 then 
			/*查询订单的放款日期*/
			select fk_date into var_loan_date from business_payment_revenue where payment_type=-2022104604 and order_id = var_order_id;			
			/*查询回款日期和放款日期之间的相隔的实际天数，即这部分融资款的实际使用天数*/
			select remit_date,datediff(remit_date,var_loan_date) into var_remittance_date,var_use_days from bus_remittance where id = var_remittance_id;
            /*BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB*/
			/*处理提前回款的情况*/
            if var_use_days <= var_bill_period then
				/*查询订单的融资金额*/
				select usd_melt_money into var_finance_money from business_payment where supplier_id = -1 and order_id = var_order_id;
				select ifnull(sum(finance_money),0) into var_has_pay_finance_money from business_finance_service_fee2 where order_id = var_order_id;
				/*
				计算融资服务费之前需要先比较一下剩余融资款和本次回款金额
				如果剩余融资款>=本次回款金额，则计算资金的基数为回款金额
				如果剩余融资款 < 本次回款金额，则计算资金的基数为剩余融资款
				*/
				if (var_finance_money - var_has_pay_finance_money) >= var_income_finance_money then
					set var_base_cal_money = var_income_finance_money;
				else
					set var_base_cal_money = var_finance_money - var_has_pay_finance_money;
				end if;
				/*回款金额融资服务费计算方式=回款金额实际使用天数*融资服务费率*本次计算金额*/
				set var_finance_service_fee = var_use_days * var_finance_rate * var_base_cal_money;
				/*提前回款金需要退回的融资服务费*/
				set var_back_finance_service_fee = (var_bill_period - var_use_days)* var_finance_rate * var_base_cal_money;
				/*将回款记录添加至融资款回款记录表*/
				insert into business_finance_service_fee2 (order_id,bill_period,finance_rate,finance_money,loan_date,remittance_date,use_days,finance_service_fee,back_finance_service_fee,reverse_finance_service_fee,finish_flag,create_date)
					values (var_order_id,var_bill_period,var_finance_rate,var_base_cal_money,var_loan_date,var_remittance_date,var_use_days,var_finance_service_fee,var_back_finance_service_fee,0,-2022101002,CURDATE());
				/*
				计算剩余的融资服务款和应退的融资服务费之间的关系
				如果应退的融资服务费 >= 剩余的融资服务款，则表明融资款已经还清了
				*/
				select ifnull(sum(finance_money+back_finance_service_fee),0) into var_sum_finance_money from business_finance_service_fee2 where order_id = var_order_id;
				if var_sum_finance_money >= var_finance_money then
					update business_finance_service_fee2 set finish_flag = -2022101001 where order_id = var_order_id;
				end if;
			else 
				/*处理逾期回款的情况*/
				/*首先需要判断一下是否有资金提前回款了，因为提前回款会产生退融资服务费的情况，可以用来加入到本次可用回销金额中*/
				select ifnull(sum(back_finance_service_fee-reverse_finance_service_fee),0) into var_sum_back_finance_service_fee from business_finance_service_fee2 where order_id = var_order_id and finance_service_fee is not null;
				set var_income_finance_money = var_income_finance_money+var_sum_back_finance_service_fee;
				open var_finance_reverse_detail_cursor;
				myLoop:loop
					fetch var_finance_reverse_detail_cursor into var_reverse_id,var_order_id,var_reverse_finance_money,var_reverse_money,var_reverse_type,var_reverse_delay_day;            
					if var_income_finance_money <=0 then 
						leave myLoop;
					end if;
					if done = 1 then
						leave myLoop;
					end if;
					set var_income_finance_money = var_income_finance_money - var_reverse_money;
					/*剩余可用销账金额-当前需要销账的金额 >= 0 ,则代表当前这笔账可以完全销掉*/
					if var_income_finance_money >= 0 then
						update business_finance_reverse_detail set has_reverse_money = var_reverse_money,has_reverse = -2022101001 where id = var_reverse_id;
						set var_reverse_actual_money = var_reverse_actual_money + var_reverse_money;
					/*剩余可用销账金额-当前需要销账的金额 < 0 ,则代表当前这笔账可以部分销掉*/
					else
						/*部分销账之后，还需要把剩余的未销部分创建一条新的待冲账记录*/
						update business_finance_reverse_detail set has_reverse_money =var_income_finance_money+var_reverse_money,has_reverse = -2022101001 where id = var_reverse_id;
						insert into mysql_debug (info1,info2,info3) values (var_reverse_finance_money,var_income_finance_money,var_reverse_money);
                        insert into business_finance_reverse_detail (order_id,finance_money,finance_rate,log_date,loan_date,bill_period,delay_day,reverse_money,reverse_type,has_reverse,has_reverse_money,creator,create_date,updator,update_date) 
							values (var_order_id,var_reverse_finance_money-var_income_finance_money-var_reverse_money,var_finance_rate,current_date(),var_loan_date,var_bill_period,var_reverse_delay_day,var_reverse_finance_money-var_income_finance_money-var_reverse_money,var_reverse_type,-2022101002,0,null,current_date(),null,current_date());                    
						set var_reverse_actual_money = var_reverse_actual_money + var_income_finance_money+var_reverse_money;
					end if;
				end loop myLoop;
				close var_finance_reverse_detail_cursor;
				set done = 0;
                /*如果有应退融资服务费参与了冲账回销，则需要记录这部分钱*/
				if var_sum_back_finance_service_fee > 0 then
					/*如果回销的实际金额 大于 参与了回销的应退融资服务费，则先冲应退融资服务费*/
                    if var_reverse_actual_money > var_sum_back_finance_service_fee then
						update business_finance_service_fee2 set reverse_finance_service_fee = back_finance_service_fee where order_id = var_order_id;
                        /*
                		实际用来回销逾期账目的资金应该 减去 应退融资服务费
						将实际回款记录添加至融资款回款记录表
                        */
						insert into business_finance_service_fee2 (order_id,bill_period,finance_rate,finance_money,loan_date,remittance_date,use_days,reverse_finance_service_fee,finish_flag,create_date)
							values (var_order_id,var_bill_period,var_finance_rate,var_reverse_actual_money-var_sum_back_finance_service_fee,var_loan_date,var_remittance_date,var_use_days,var_sum_back_finance_service_fee,-2022101002,CURDATE());
					else
						/*把有应退融资服务费的记录找出来，逐条操作*/
                        set var_temp_reverse_actual_money = var_reverse_actual_money;
						open var_cur2;
						myLoop:loop
							fetch var_cur2 into var_finance_fee2_id,var_can_use_service_fee;           
							if var_temp_reverse_actual_money <= 0 then
								leave myLoop;
                            end if;
                            if done = 1 then
								leave myLoop;
							end if;
                            set var_temp_reverse_actual_money = var_temp_reverse_actual_money - var_can_use_service_fee;
                            if var_temp_reverse_actual_money > 0 then 
								update business_finance_service_fee2 set reverse_finance_service_fee = back_finance_service_fee where id = var_finance_fee2_id;
                            else 
								update business_finance_service_fee2 set reverse_finance_service_fee = reverse_finance_service_fee + var_can_use_service_fee+var_temp_reverse_actual_money where id = var_finance_fee2_id;
                            end if;
						end loop myLoop;
						close var_cur2;							
                    end if;
				else
					insert into business_finance_service_fee2 (order_id,bill_period,finance_rate,finance_money,loan_date,remittance_date,use_days,reverse_finance_service_fee,finish_flag,create_date)
						values (var_order_id,var_bill_period,var_finance_rate,var_reverse_actual_money,var_loan_date,var_remittance_date,var_use_days,0,-2022101002,CURDATE());						
                end if;
                /*本次冲账之后需要判断所有账目是否都已经冲完，冲完则代表融资款还清了*/
                select count(1) into var_has_reverse from business_finance_reverse_detail where order_id =var_order_id and has_reverse = -2022101002;
				if var_has_reverse = 0 then
                    update business_finance_service_fee2 set finish_flag = -2022101001 where order_id = var_order_id;                  
                end if;
			end if;
			/*BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB*/
		end if;
        /*EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE*/
	end if;
	/*CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC*/
end;

